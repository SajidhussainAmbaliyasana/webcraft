import { Box, Toolbar } from "@mui/material";

import { useSelector } from "react-redux";

import Sidebar from "../components/SideBar";
import TopNavbar from "../components/TopNavbar";

import DashboardD from "../components/DashboardD";

import { selectSidebarCollapsed } from "../redux/slices/uiSlice";

import { COLORS } from "../theme";

const Dashboard = () => {
  const collapsed = useSelector(
    selectSidebarCollapsed
  );

  return (
    <Box
      sx={{
        display: "flex",

        minHeight: "100vh",

        background: COLORS.bg,
      }}
    >
      {/* Sidebar */}

      <Sidebar />

      {/* Main section */}

      <Box
        component="main"
        sx={{
          flex: 1,

          display: "flex",

          flexDirection: "column",

          minWidth: 0,
        }}
      >
        {/* Top navbar */}

        <TopNavbar pageTitle="Dashboard" />

        {/* Navbar spacing */}

        <Toolbar
          sx={{
            minHeight:
              "60px !important",
          }}
        />

        {/* Dashboard content */}

        <Box
          sx={{
            flex: 1,

            p: {
              xs: 2.5,
              md: 4,
            },

            overflowY: "auto",
          }}
        >
          <DashboardD />
        </Box>
      </Box>
    </Box>
  );
};

export default Dashboard;