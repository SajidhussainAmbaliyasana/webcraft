import React from 'react'

const Website = () => {
  return (
    <div>
      <p>this is the website page</p>
    </div>
  )
}

export default Website
