import { useNavigate } from "react-router-dom";

import {
  Box,
  Grid,
  Typography,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  alpha,
} from "@mui/material";

import LanguageIcon from "@mui/icons-material/Language";
import AddIcon from "@mui/icons-material/Add";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import EditNoteIcon from "@mui/icons-material/EditNote";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import RocketLaunchOutlinedIcon from "@mui/icons-material/RocketLaunchOutlined";

import { ROUTES } from "../constants";

import { COLORS } from "../theme";
import Dashboard from "../pages/Dashboard";

const StatCard = ({
  label,
  value,
  icon,
  accent,
}) => (
  <Card
    sx={{
      position: "relative",
      overflow: "hidden",
    }}
  >
    {accent && (
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          pointerEvents: "none",

          background: `radial-gradient(
            ellipse 80% 60% at 100% 0%,
            ${alpha(accent, 0.08)} 0%,
            transparent 70%
          )`,
        }}
      />
    )}

    <CardContent sx={{ p: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          mb: 2,
        }}
      >
        <Typography variant="subtitle2">
          {label}
        </Typography>

        <Box
          sx={{
            width: 36,
            height: 36,
            borderRadius: "9px",

            background: accent
              ? alpha(accent, 0.12)
              : alpha(
                  COLORS.borderSubtle,
                  0.5
                ),

            border: `1px solid ${
              accent
                ? alpha(accent, 0.25)
                : COLORS.borderSubtle
            }`,

            display: "flex",
            alignItems: "center",
            justifyContent: "center",

            color:
              accent || COLORS.textMuted,
          }}
        >
          {icon}
        </Box>
      </Box>

      <Typography
        sx={{
          fontWeight: 800,
          fontSize: "2rem",
          letterSpacing: "-1px",
          color: COLORS.textPrimary,
        }}
      >
        {value}
      </Typography>
    </CardContent>
  </Card>
);

const QuickAction = ({
  label,
  description,
  icon,
  accent,
  onClick,
}) => (
  <Card
    onClick={onClick}
    sx={{
      cursor: "pointer",
      p: 2.5,

      display: "flex",
      gap: 2,
      alignItems: "center",

      transition: "all 0.18s",

      "&:hover": {
        border: `1px solid ${
          accent
            ? alpha(accent, 0.4)
            : COLORS.borderMid
        }`,

        transform: "translateY(-2px)",

        boxShadow:
          "0 12px 32px rgba(0,0,0,0.3)",
      },
    }}
  >
    <Box
      sx={{
        width: 40,
        height: 40,
        borderRadius: "10px",

        flexShrink: 0,

        background: accent
          ? `linear-gradient(
              135deg,
              ${accent},
              ${COLORS.purple}
            )`
          : alpha(
              COLORS.borderSubtle,
              0.5
            ),

        display: "flex",
        alignItems: "center",
        justifyContent: "center",

        color: "#fff",
      }}
    >
      {icon}
    </Box>

    <Box>
      <Typography
        sx={{
          fontWeight: 600,
          fontSize: "0.9rem",
          color: COLORS.textPrimary,
          mb: 0.3,
        }}
      >
        {label}
      </Typography>

      <Typography
        variant="body2"
        sx={{
          fontSize: "0.78rem",
        }}
      >
        {description}
      </Typography>
    </Box>

    <ArrowForwardIcon
      sx={{
        ml: "auto",
        fontSize: 16,
        color: COLORS.textMuted,
      }}
    />
  </Card>
);

const DashboardD = () => {
  const navigate = useNavigate();

  // Temporary static data

  const user = {
    name: "Sajid Hussain",
  };

  const websites = [];

  const firstName =
    user?.name?.split(" ")[0] || "there";

  const hour = new Date().getHours();

  const greeting =
    hour < 12
      ? "Good morning"
      : hour < 18
      ? "Good afternoon"
      : "Good evening";

  const totalPages = 0;

  const totalViews = 0;

  const publishedCount = 0;

  //const recentSites = [];

  return (
    <Box>
      {/* Header */}

      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",

          mb: 5,

          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Box>
          <Typography
            variant="subtitle2"
            sx={{ mb: 0.5 }}
          >
            {greeting.toUpperCase()}
          </Typography>

          <Typography
            variant="h3"
            sx={{
              fontSize:
                "clamp(1.5rem, 3vw, 2.2rem)",

              mb: 0.5,
            }}
          >
            {greeting}, {firstName} 👋
          </Typography>

          <Typography
            variant="body1"
            sx={{
              fontSize: "0.9rem",
            }}
          >
            Here's what's happening with
            your websites today.
          </Typography>
        </Box>

        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() =>
            navigate(ROUTES.WEBSITES)
          }
          sx={{
            height: 44,
            whiteSpace: "nowrap",
          }}
        >
          New Website
        </Button>
      </Box>

      {/* Stats */}

      <Grid
        container
        spacing={2.5}
        sx={{ mb: 4 }}
      >
        {[
          {
            label: "TOTAL WEBSITES",
            value: websites.length,

            icon: (
              <LanguageIcon
                sx={{ fontSize: 18 }}
              />
            ),

            accent: COLORS.cyan,
          },

          {
            label: "TOTAL PAGES",
            value: totalPages,

            icon: (
              <EditNoteIcon
                sx={{ fontSize: 18 }}
              />
            ),

            accent: COLORS.purple,
          },

          {
            label: "TOTAL VIEWS",
            value: totalViews,

            icon: (
              <VisibilityOutlinedIcon
                sx={{ fontSize: 18 }}
              />
            ),

            accent: COLORS.pink,
          },

          {
            label: "PUBLISHED",
            value: publishedCount,

            icon: (
              <TrendingUpIcon
                sx={{ fontSize: 18 }}
              />
            ),

            accent: COLORS.green,
          },
        ].map((s) => (
          <Grid
            item
            xs={12}
            sm={6}
            lg={3}
            key={s.label}
          >
            <StatCard {...s} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2.5}>
        {/* Quick actions */}

        <Grid item xs={12} md={7}>
          <Card sx={{ height: "100%" }}>
            <CardContent sx={{ p: 3 }}>
              <Typography
                variant="h6"
                sx={{
                  mb: 0.5,
                  fontSize: "1rem",
                }}
              >
                Quick Actions
              </Typography>

              <Typography
                variant="body2"
                sx={{ mb: 3 }}
              >
                Jump right into building.
              </Typography>

              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 1.5,
                }}
              >
                <QuickAction
                  label="Create a new website"
                  description="Start from scratch or pick a template"
                  icon={
                    <AddIcon
                      sx={{ fontSize: 18 }}
                    />
                  }
                  accent={COLORS.cyan}
                  onClick={() =>
                    navigate(
                      ROUTES.WEBSITES
                    )
                  }
                />

                <QuickAction
                  label="Manage websites"
                  description="View, edit and publish all your sites"
                  icon={
                    <LanguageIcon
                      sx={{ fontSize: 18 }}
                    />
                  }
                  accent={COLORS.purple}
                  onClick={() =>
                    navigate(
                      ROUTES.WEBSITES
                    )
                  }
                />

                <QuickAction
                  label="Open editor"
                  description="Visual component-based page editor"
                  icon={
                    <EditNoteIcon
                      sx={{ fontSize: 18 }}
                    />
                  }
                  onClick={() =>
                    navigate(
                      ROUTES.WEBSITES
                    )
                  }
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent websites */}

        <Grid item xs={12} md={5}>
          <Card sx={{ height: "100%" }}>
            <CardContent sx={{ p: 3 }}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent:
                    "space-between",

                  alignItems: "center",

                  mb: 3,
                }}
              >
                <Box>
                  <Typography
                    variant="h6"
                    sx={{
                      fontSize: "1rem",
                      mb: 0.3,
                    }}
                  >
                    Recent Websites
                  </Typography>

                  <Typography variant="body2">
                    Your latest projects.
                  </Typography>
                </Box>

                <Chip
                  label={`${websites.length} total`}
                  size="small"
                  color="primary"
                />
              </Box>

              <Divider sx={{ mb: 1 }} />

              <Box
                sx={{
                  py: 4,

                  display: "flex",
                  flexDirection: "column",

                  alignItems: "center",

                  gap: 1.5,
                }}
              >
                <LanguageIcon
                  sx={{
                    fontSize: 26,
                    color: COLORS.textMuted,
                  }}
                />

                <Typography
                  sx={{
                    fontSize: "0.75rem",
                    color: COLORS.textMuted,
                    textAlign: "center",
                  }}
                >
                  No websites yet.
                  <br />
                  Create your first one to
                  get started.
                </Typography>

                <Button
                  size="small"
                  variant="outlined"
                  onClick={() =>
                    navigate(
                      ROUTES.WEBSITES
                    )
                  }
                >
                  Get started
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* CTA */}

      <Card
        sx={{
          mt: 3,
          position: "relative",
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",

            background: `radial-gradient(
              ellipse 60% 80% at 100% 50%,
              ${alpha(COLORS.purple, 0.12)}
              0%,
              transparent 70%
            )`,
          }}
        />

        <CardContent
          sx={{
            p: 3,

            display: "flex",
            justifyContent:
              "space-between",

            alignItems: "center",

            flexWrap: "wrap",
            gap: 2,
          }}
        >
          <Box>
            <Typography
              variant="h6"
              sx={{ mb: 0.5 }}
            >
              Ready to build?
            </Typography>

            <Typography variant="body2">
              Create your first website and
              experience the future of web
              building.
            </Typography>
          </Box>

          <Button
            variant="contained"
            endIcon={
              <RocketLaunchOutlinedIcon />
            }
            onClick={() =>
              navigate(ROUTES.WEBSITES)
            }
          >
            Start building
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};

export default DashboardD;