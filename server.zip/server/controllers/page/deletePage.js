import mongoose from "mongoose";
import Page from "../../models/page.js";
import Component from "../../models/component.js";

const deletePage = async (req, res) => {
    try {
        const { pageId } = req.params;

        if (!mongoose.Types.ObjectId.isValid(pageId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid page id"
            });
        }

        const pageObjectId = new mongoose.Types.ObjectId(pageId);

        const page = await Page.findOne({
            _id: pageObjectId,
            isDeleted: false
        }).select("isHomePage");

        if (!page) {
            return res.status(404).json({
                success: false,
                message: "Page not found"
            });
        }

        if (page.isHomePage) {
            return res.status(400).json({
                success: false,
                message: "Homepage cannot be deleted"
            });
        }

        await Component.updateMany(
            {
                pageId: pageObjectId,
                isDeleted: false
            },
            {
                $set: {
                    isDeleted: true,
                    deletedAt: new Date()
                }
            }
        );

        await Page.updateOne(
            {
                _id: pageObjectId,
                isDeleted: false
            },
            {
                $set: {
                    isDeleted: true,
                    deletedAt: new Date(),
                    lastSavedAt: new Date()
                }
            }
        );

        return res.status(200).json({
            success: true,
            message: "Page and related components deleted successfully"
        });

    } catch (error) {
        console.error("Delete page error:", error);

        return res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
};

export default deletePage;